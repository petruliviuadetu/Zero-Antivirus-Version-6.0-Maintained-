Hello, This antivirus is maintained, cool gui, if you have any suggestions, make an issue. 

This antivirus has an gui, much more, the gui is just buttons ;-; , im still updating it!

If you want to help, make an issue.

-Zero Antivirus Corporation.