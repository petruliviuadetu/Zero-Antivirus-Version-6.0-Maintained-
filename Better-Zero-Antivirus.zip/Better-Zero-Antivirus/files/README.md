## About
This is a very simple program that can be used in your batch projects as a function to display a very enhanced
GUI Buttons.

 * Follow the example for usage.
 * There is comments in the "Button.bat" file to help understand how the program works.

## Screenshot
![](https://raw.githubusercontent.com/Psi505/Batch-GUI-Button/main/image.png)
